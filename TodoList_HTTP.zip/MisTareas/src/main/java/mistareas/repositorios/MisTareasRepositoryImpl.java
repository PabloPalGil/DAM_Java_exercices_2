package mistareas.repositorios;

import mistareas.entidades.Task;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.List;

@Repository
public class MisTareasRepositoryImpl implements MisTareasRepository{
    private final JdbcTemplate jdbcTemplate;

    public MisTareasRepositoryImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Task> getMisTareas() {
        String sql = "SELECT id, description, status FROM task";
        return jdbcTemplate.query(sql, (resultSet, rowNum) ->
                new Task(
                        resultSet.getLong("id"),
                        resultSet.getString("description"),
                        resultSet.getString("status")
                )
        );
    }

    @Override
    public Task getMiTarea(Long id) {
        String sql = "SELECT id, description, status FROM task WHERE id = ?";
        List<Task> tareas = jdbcTemplate.query(sql, new Object[]{id}, (resultSet, rowNum) ->
                new Task(
                        resultSet.getLong("id"),
                        resultSet.getString("description"),
                        resultSet.getString("status")
                )
        );

        return tareas.isEmpty() ? null : tareas.get(0);
    }


    //Añadimos la función de guardar en el repositorio (nuestra bd):
    @Override
    public Task guardar(Task task) {
        if (task.getId() == null) {
            String sql = "INSERT INTO task (description, status) VALUES (?, ?)";
            int insert = jdbcTemplate.update(sql, task.getDescription(), task.getStatus());
            if(insert == 1) {
                return task;
            } else{
                return null;
            }
        } else{
            String sql = "UPDATE task SET description = ?, status = ? WHERE id = ?";
            int update = jdbcTemplate.update(sql, task.getDescription(), task.getStatus(), task.getId());
            if(update == 1) {
                return task;
            } else{
                return null;
            }
        }

    }

    //Añadimos la función de eliminar de la bd:
    @Override
    public void eliminar(Long id) {
        String sql = "DELETE FROM task WHERE id = ?";
        int lineas = jdbcTemplate.update(sql, id);
        if(lineas != 0){
            System.out.println("Tarea " + id + " eliminada.");
        } else {
            System.out.println("Error al eliminar la tarea " + id + " (seguramente no existe).");
        }
    }
}
