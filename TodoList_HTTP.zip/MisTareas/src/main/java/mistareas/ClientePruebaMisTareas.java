package mistareas;

import mistareas.entidades.Task;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

public class ClientePruebaMisTareas {
    private static final String BASE_URL = "http://localhost:8080/tasks";

    public static void main(String[] args) {
        // Instancia de RestTemplate
        RestTemplate restTemplate = new RestTemplate();

        // Obtener todas las tareas
        ResponseEntity<String> responseAll = restTemplate.getForEntity(BASE_URL, String.class);
        System.out.println("Obtener todas las tareas:");
        System.out.println(responseAll.getBody());
        System.out.println();

        // Obtener una tarea por ID (supongamos que la tarea con ID 1 existe)
        Long taskId = 1L;
        ResponseEntity<String> responseById = restTemplate.getForEntity(BASE_URL + "/" + taskId, String.class);
        System.out.println("Obtener tarea por ID:");
        System.out.println(responseById.getBody());
        System.out.println();

        //Guardar una tarea nueva:
        System.out.println("Guardar una tarea nueva:");
        System.out.println("Vamos a añadir la tarea 4...");
        Task nuevaTarea = new Task("Tarea 4", "PENDIENTE");
        ResponseEntity<Task> responseSave = restTemplate.postForEntity(BASE_URL, nuevaTarea, Task.class);
        if(responseSave.hasBody()){
            System.out.println("Tarea 4 guardada con exito");
        } else {
            System.out.println("Error al guardar la tarea");
        }
        System.out.println();

        //Modificar la tarea 1:
        System.out.println("Modificar una tarea:");
        System.out.println("Vamos a completar la tarea 1...");
        nuevaTarea = new Task("Tarea 1", "COMPLETADA");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Task> requestEntity = new HttpEntity<>(nuevaTarea, headers);
        ResponseEntity<Task> responseUpdate = restTemplate.exchange(BASE_URL + "/" + 1, HttpMethod.PUT, requestEntity, Task.class);
        System.out.println(responseUpdate.getBody());
        System.out.println("Tarea 1 completada con éxito.");
        System.out.println();

        //Eliminar la tarea nueva:
        System.out.println("Eliminar tarea:");
        System.out.println("Vamos a eliminar la tarea 2...");
        restTemplate.delete(BASE_URL + "/" + 2);
        System.out.println();

        // Obtener todas las tareas
        responseAll = restTemplate.getForEntity(BASE_URL, String.class);
        System.out.println("Obtener todas las tareas:");
        System.out.println(responseAll.getBody());
        System.out.println();
    }
}

/* Para que funcione la generación automática de id hemos creado el campo id de la tabla task
en la base de datos como auto_increment. A continuación, el script sql utilizado:
 //1 - Crear la tabla task:
CREATE TABLE task (
    id int auto_increment primary key,
    description varchar(120),
    status varchar(50)
);

2 - Rellenar con valores de prueba:
INSERT INTO task (id, description, status)
VALUES
(1, 'Tarea 1', 'PENDIENTE'),
(2, 'Tarea 2', 'PENDIENTE'),
(3, 'Tarea 3', 'PENDIENTE');
 */
