package mistareas.entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


public class Task {
    private Long id;

    private String description;
    private String status;

    public Task(){}//Hay que añadir un constructor vacío por defecto o Jpa no sabe construir la entidad

    public Task(Long id, String description, String status) {
        this.id  = id;
        this.description = description;
        this.status = status;
    }

    public Task(String description, String status) {
        this.description = description;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Task{" + "id=" + id + ", description=" + description + ", status=" + status + '}';
    }
}
