package Tema0;

class Calculadora {
    public static double sumar(double a, double b) {
        return a + b;
    }

    public static double restar(double a, double b) {
        return a - b;
    }

    public static double multiplicar(double a, double b) {
        return a * b;
    }

    public static double dividir(double a, double b) {
        if(b == 0){
            System.out.println("División por cero.");
            return Double.NaN;
        } else{
            return a / b;
        }
    }
}

public class Ejercicio5 {
    public static void main(String[] args) {
        System.out.println(Calculadora.sumar(5, 3));
        System.out.println(Calculadora.restar(5, 3));
        System.out.println(Calculadora.multiplicar(5, 3));
        System.out.println(Calculadora.dividir(5, 0));
    }
}
