package Tema0;

public class Ejercicio3 {
    public static void main(String[] args) {
        Rectangulo rectangulo = new Rectangulo(5.0, 3.0);
        double areaRectangulo = rectangulo.calcularArea();
        System.out.println("Área rectángulo = " + areaRectangulo);

        Triangulo triangulo = new Triangulo(5.0, 3.0);
        double areaTriangulo = triangulo.calcularArea();
        System.out.println("Área triángulo = " + areaTriangulo);
    }
}

interface Poligono {
    double calcularArea();
}

class Rectangulo implements Poligono {
    double ancho;
    double alto;

    public Rectangulo(double ancho, double alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public double calcularArea() {
        return ancho * alto;
    }
}

class Triangulo implements Poligono {
    double base;
    double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return base * altura / 2;
    }
}
