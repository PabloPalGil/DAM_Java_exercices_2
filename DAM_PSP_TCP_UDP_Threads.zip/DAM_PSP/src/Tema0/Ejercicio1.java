package Tema0;

public class Ejercicio1 {

    public static void main(String[] args) {
        Persona persona = new Persona("Juan");

        System.out.println("Nombre: " + persona.nombre);
    }



}

class Persona{
    String nombre;

    Persona(String nombre){
        this.nombre = nombre;
    }
}