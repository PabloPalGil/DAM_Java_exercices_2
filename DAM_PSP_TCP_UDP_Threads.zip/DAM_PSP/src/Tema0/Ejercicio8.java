package Tema0;

import java.util.Scanner;
import java.util.Random;

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        double numeroAdivinar = random.nextInt(100) + 1;
        int intentos = 0;
        boolean adivinado = false;

        System.out.println("Bienvenido a: ¡Adivina el Número!");

        while (!adivinado) {
            System.out.print("Introduce un numero del 1 al 100: ");
            int intento = sc.nextInt();
            intentos++;

            if(intento < 1 || intento > 100) {
                System.out.println("¡Número fuera de rango!\n");
            } else if(intento < numeroAdivinar){
                System.out.println("El número a adivinar es mayor.\n");
            } else if(intento > numeroAdivinar) {
                System.out.println("El número a adivinar es menor.\n");
            } else{
                adivinado = true;
                System.out.println("¡Enhorabuena! Has acertado en el intento " + intentos + "\n");
            }
        }

        System.out.println("¡Gracias por jugar!");
        sc.close();
    }
}
