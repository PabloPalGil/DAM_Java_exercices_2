package Tema0;

public class Ejercicio2 {
    public static void main(String[] args) {
        PersonaConEdad persona = new PersonaConEdad("Ana", 25);
        System.out.println("Nombre: " + persona.nombre + "\nEdad: " + persona.edad);
    }
}

class PersonaConEdad extends Persona{
    int edad;
    PersonaConEdad(String nombre, int edad){
        super(nombre);
        this.edad = edad;
    }
}