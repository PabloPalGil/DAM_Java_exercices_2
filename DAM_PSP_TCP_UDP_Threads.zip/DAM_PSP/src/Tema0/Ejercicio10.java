package Tema0;

import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese una lista de números enteros separados por comas:");
        String entrada = scanner.nextLine();

        String[] numerosComoTexto = entrada.split(",");
        int[] numeros = new int[numerosComoTexto.length];

        for (int i = 0; i < numerosComoTexto.length; i++) {
            numeros[i] = Integer.parseInt(numerosComoTexto[i]);
        }

        int suma = 0;
        int minimo = Integer.MAX_VALUE;
        int maximo = Integer.MIN_VALUE;

        for (int numero : numeros) {
            suma += numero;

            if (numero < minimo) {
                minimo = numero;
            }

            if (numero > maximo) {
                maximo = numero;
            }
        }

        double promedio = (double) suma / numeros.length;

        System.out.println("Suma: " + suma);
        System.out.println("Promedio: " + promedio);
        System.out.println("Mínimo: " + minimo);
        System.out.println("Máximo: " + maximo);

        scanner.close();
    }
}