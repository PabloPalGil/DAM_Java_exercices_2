package Tema0;

import java.util.ArrayList;

class Libro {
    String titulo;
    String autor;
    int anyoPublicacion;

    Libro(String titulo, String autor, int anyoPublicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.anyoPublicacion = anyoPublicacion;
    }

    String getInfoLibro() {
        return "Título: " + titulo + ", Autor: " + autor + ", Año de Publicación: " + anyoPublicacion;
    }
}

public class Ejercicio6 {
    public static void main(String[] args) {
        ArrayList<Libro> biblioteca = new ArrayList<>();
        biblioteca.add(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes Saavedra", 1605));
        biblioteca.add(new Libro("1984", "George Orwell", 1949));
        biblioteca.add(new Libro("The Return of the King", "J.R.R. Tolkien", 1955));

        for (Libro libro : biblioteca) {
            System.out.println(libro.getInfoLibro());
        }
    }
}
