package Tema0;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Gasto> listaDeGastos = new ArrayList<>();

        System.out.println("Bienvenido al \"Registro de Gastos Personales\"");

        do {
            System.out.println("Introduce la descripción del gasto (o [fin] para salir):");
            String descripcion = sc.nextLine();

            if(descripcion.equalsIgnoreCase("fin")){
                break;
            }

            System.out.println("Introduce la cantidad del gasto:");
            double cantidad = sc.nextDouble();

            sc.nextLine();//Limpia el buffer de entrada

            listaDeGastos.add(new Gasto(descripcion, cantidad));
        } while (true);

        if(listaDeGastos.size() > 0){
            System.out.println("\nLista de gastos:");
            double totalGastos = 0d;
            for(Gasto gasto : listaDeGastos){
                System.out.println(gasto.getDescripcion() + "\t: " + gasto.getCantidad() + " $");
                totalGastos += gasto.getCantidad();
            }
            System.out.println("Total: " + totalGastos + " $");
        } else{
            System.out.println("No se registraron gastos.");
        }

        System.out.println("\nGracias por utilizar el \"Registro de Gastos\"");
        sc.close();
    }
}

class Gasto {
    private String descripcion;
    private double cantidad;

    Gasto(String descripcion, double cantidad) {
        this.descripcion = descripcion;
        this.cantidad = cantidad;
    }

    public String getDescripcion(){
        return descripcion;
    }

    public double getCantidad(){
        return cantidad;
    }
}
