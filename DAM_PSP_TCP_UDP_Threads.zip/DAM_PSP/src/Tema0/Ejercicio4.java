package Tema0;

class Banco {
    double saldo;

    Banco(){
        saldo = 0d;
    }

    void depositar(double cantidad){
        saldo += cantidad;
    }

    void retirar(double cantidad){
        if(saldo >= cantidad){
            saldo -= cantidad;
        } else {
            System.out.println("Saldo insuficiente.");
        }
    }
}

public class Ejercicio4 {
    public static void main(String[] args) {
        Banco cuenta = new Banco();

        cuenta.depositar(100d);
        cuenta.retirar(50d);
        cuenta.retirar(200d);
        System.out.println("Saldo actual de la cuenta: " + cuenta.saldo);
    }
}
