package Tema0;

interface FiguraGeometrica {
    double calcularArea();
    double calcularPerimetro();
}

class Circulo implements FiguraGeometrica {
    private double radio;

    Circulo(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public double calcularPerimetro() {
        return 2 * Math.PI * radio;
    }
}

class Cuadrado implements FiguraGeometrica {
    private double lado;

    Cuadrado(double lado) {
        this.lado = lado;
    }

    @Override
    public double calcularArea() {
        return lado * lado;
    }

    @Override
    public double calcularPerimetro() {
        return lado * 4;
    }
}

public class Ejercicio7 {
    public static void main(String[] args) {
        FiguraGeometrica[] figuras = new FiguraGeometrica[3];

        figuras[0] = new Circulo(5.0);
        figuras[1] = new Cuadrado(4.0);
        figuras[2] = new Circulo(3.0);

        for (int i = 0; i < figuras.length; i++){
            System.out.println("Área de la figura " + (i + 1) + ": " + figuras[i].calcularArea());
            System.out.println("Perímetro de la figura " + (i + 1) + ": " + figuras[i].calcularPerimetro() + "\n");
        }
    }
}
