package Tema2;

public class Tienda {
    private int stock;

    //Constructor
    public Tienda(int stock) {
        this.stock = stock;
    }

    //El método comprarProducto debe ser synchronized para que dos clientes no puedan comprar
    //del mismo stock al mismo tiempo
    public synchronized void comprarProducto(int cantidad, int clienteId) {
        if (cantidad <= stock) {
            stock -= cantidad;
            System.out.println("Cliente " + clienteId + " compró " + cantidad + " productos.");
            System.out.println("Stock disponible: " + stock);
        } else {
            System.out.println("Cliente " + clienteId + " intentó comprar " + cantidad +
                    " productos, pero no hay suficiente stock.");
        }
    }
}
