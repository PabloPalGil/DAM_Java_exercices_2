package Tema2;

import java.util.Scanner;

public class Ej04_1RepartoCiclico {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la cantidad total de trabajo (N): ");
        int N = sc.nextInt();

        System.out.print("Introduce el número de hilos (M): ");
        int M = sc.nextInt();

        //Definimos el array de hilos solicitados:
        Thread[] hilos = new Thread[M];

        System.out.println("COMIENZA LA IMPLEMENTACIÓN CÍCLICA:");

        //Inicializamos cada hilo con N, M y un id para identificarlos del 0 a M-1
        for(int i = 0; i < M; i++) {
            hilos[i] = new Thread(new HiloCiclico(N, M, i));
            hilos[i].start();//Arrancamos el hilo.
            //Cada hilo calculará los indices del trabajo que debe realizar según un reparto cíclico.
        }

        //Esperamos a que todos los hilos terminen:
        for (Thread hilo : hilos) {
            try{
                hilo.join();
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }

        System.out.println("Todos los hilos han finalizado.");
    }
}


class HiloCiclico implements Runnable{
    private int N;
    private int M;
    private int id;

    HiloCiclico(int N, int M, int id) {
        this.N = N;
        this.M = M;
        this.id = id;
    }

    @Override
    public void run() {
        //El hilo determina qué índices del trabajo total debe procesar según el reparto cíclico:
        for(int i = id; i < N; i += M) {
            System.out.println("Soy el hilo " + id + ", digo el número " +
                    i + " y el cuadrado es " + CalculaCuadrado(i));
        }
    }

    public int CalculaCuadrado(int n){
        return n*n;
    }
}