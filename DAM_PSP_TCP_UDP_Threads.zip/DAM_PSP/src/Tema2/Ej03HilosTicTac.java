package Tema2;

public class Ej03HilosTicTac {
    public static void main(String[] args) {
        int intervalo = 500;//intervalo en ms entre TIC-TACs

        //Creamos las instancias Tic y Tac
        Runnable tic = new Repetidor(Thread.MIN_PRIORITY, "TIC-", intervalo);
        Runnable tac = new Repetidor(Thread.MAX_PRIORITY, "TAC-", intervalo);

        //Creamos los hilos
        Thread hilo1 = new Thread(tic);
        Thread hilo2 = new Thread(tac);

        //Arrancamos los hilos:
        hilo1.start();
        hilo2.start();
    }
}

class Repetidor implements Runnable {
    private String mensaje;
    private int intervalo;
    private Thread thread;

    public Repetidor(int priority, String mensaje, int intervalo) {
        this.mensaje = mensaje;
        this.intervalo = intervalo;
        this.thread = new Thread(this);
        this.thread.setPriority(priority);
    }

    @Override
    public void run() {
        while(true) {
            System.out.print(mensaje);
            try {
                Thread.sleep(intervalo);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}