package Tema2;

public class Cliente extends Thread {
    private Tienda tienda;
    private int cantidad;
    private int id;

    public Cliente(Tienda tienda, int cantidad, int id) {
        this.tienda = tienda;
        this.cantidad = cantidad;
        this.id = id;
    }

    @Override
    public void run() {
        tienda.comprarProducto(cantidad, id);
    }
}
