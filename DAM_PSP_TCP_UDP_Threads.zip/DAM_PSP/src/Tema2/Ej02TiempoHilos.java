package Tema2;

import static Tema2.Ej02TiempoHilos.esPrimo;

public class Ej02TiempoHilos {
    public static void main(String[] args) {
        //Creamos los 4 hilos con diferentes rangos de valores:
        CalculoPrimo hilo1 = new CalculoPrimo(1, 100000);
        CalculoPrimo hilo2 = new CalculoPrimo(100001, 200000);
        CalculoPrimo hilo3 = new CalculoPrimo(200001, 300000);
        CalculoPrimo hilo4 = new CalculoPrimo(300001, 400000);

        //Marcamos el instante inicial
        long tiempoInicio = System.currentTimeMillis();

        //Arrancamos los hilos:
        hilo1.start();
        hilo2.start();
        hilo3.start();
        hilo4.start();

        //Esperamos a que los hilos terminen
        try{
            hilo1.join();
            hilo2.join();
            hilo3.join();
            hilo4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Calculamos el tiempo de ejecución y lo mostramos:
        long tiempoTranscurrido = System.currentTimeMillis() - tiempoInicio;
        System.out.println("Tiempo de ejecución con 4 hilos (Threads): " + tiempoTranscurrido + " ms"); //4256 ms

        //Lo mismo pero con Runnable, por comparar:
        Thread[] hilosRunnable = new Thread[4]; //Definimos los hilos

        //Asignamos los objetos Runnable a cada hilo
        hilosRunnable[0] = new Thread(new CalculoPrimoRunnable(1, 100000));
        hilosRunnable[1] = new Thread(new CalculoPrimoRunnable(100001, 200000));
        hilosRunnable[2] = new Thread(new CalculoPrimoRunnable(200001, 300000));
        hilosRunnable[3] = new Thread(new CalculoPrimoRunnable(300001, 400000));

        //Marcamos el instante inicial
        tiempoInicio = System.currentTimeMillis();

        //Arrancamos los hilos
        for(int i = 0; i < hilosRunnable.length; i++){
            hilosRunnable[i].start();
        }

        //Esperamos a que terminen:
        try{
            for(int i = 0; i < hilosRunnable.length; i++){
                hilosRunnable[i].join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Calculamos el tiempo de ejecución y lo mostramos:
        tiempoTranscurrido = System.currentTimeMillis() - tiempoInicio;
        System.out.println("Tiempo de ejecución con 4 hilos (Runnable): " + tiempoTranscurrido + " ms"); //4133 ms

    }

    public static boolean esPrimo(int numero){
        // Los números menores o iguales a 1 no son primos
        if (numero <= 1) {
            return false;
        }
        //Comprobamos si es divisible por algún número desde 2 hasta 'numero - 1'
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0) {
                return false; // Si es divisible, no es primo
            }
        }
        return true; // Si no es divisible por ningún número, es primo
    }
}

class CalculoPrimoRunnable implements Runnable{
    private int numInicio;
    private int numFinal;

    //Definimos un constructor que acepte los 2 números del rango
    public CalculoPrimoRunnable(int numInicio, int numFinal) {
        this.numInicio = numInicio;
        this.numFinal = numFinal;
    }

    @Override
    public void run(){
        //Calculamos si los numeros entre numInicio y numFinal son primos
        for(int i = numInicio; i <= numFinal; i++){
            if(esPrimo(i))
                System.out.println(i);
        }
    }
}


class CalculoPrimo extends Thread{
    private int numInicio;
    private int numFinal;

    //Definimos un constructor que acepte los 2 números del rango
    public CalculoPrimo(int numInicio, int numFinal) {
        this.numInicio = numInicio;
        this.numFinal = numFinal;
    }

    @Override
    public void run(){
        //Calculamos si los numeros entre numInicio y numFinal son primos
        for(int i = numInicio; i <= numFinal; i++){
            if(esPrimo(i))
                System.out.println(i);
        }
    }

}