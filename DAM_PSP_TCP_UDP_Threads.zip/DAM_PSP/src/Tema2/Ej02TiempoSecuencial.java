package Tema2;

public class Ej02TiempoSecuencial {
    public static void main(String[] args) {
        int numFinal = 400000;//Calculamos hasta este número

        //Marcamos el instante inicial
        long tiempoInicio = System.currentTimeMillis();

        //Ejecutamos el cálculo de números primos:
        for(int i = 1; i <= numFinal; i++){
            if(esPrimo(i))
                System.out.println(i);
        }

        //Marcamos el instante final
        long tiempoTranscurrido = System.currentTimeMillis() - tiempoInicio;

        //Mostramos el tiempo transcurrido:
        System.out.println("Tiempo de ejecución secuencial: " + tiempoTranscurrido + " ms");
    }

    public static boolean esPrimo(int numero){
        // Los números menores o iguales a 1 no son primos
        if (numero <= 1) {
            return false;
        }
        //Comprobamos si es divisible por algún número desde 2 hasta 'numero - 1'
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0) {
                return false; // Si es divisible, no es primo
            }
        }
        return true; // Si no es divisible por ningún número, es primo
    }
}

