package Tema2;

public class PrincipalTienda {
    public static void main(String[] args) {
        //Instanciamos una tienda con 12 de stock
        Tienda tienda = new Tienda(12);

        //Creamos 3 clientes que quieren comprar
        Cliente cliente1 = new Cliente(tienda, 4, 1);
        Cliente cliente2 = new Cliente(tienda, 6, 2);
        Cliente cliente3 = new Cliente(tienda, 3, 3);

        //Iniciamos los hilos de compra
        cliente1.start();
        cliente2.start();
        cliente3.start();

        //Esperamos a que terminen los hilos
        try {
            cliente1.join();
            cliente2.join();
            cliente3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
