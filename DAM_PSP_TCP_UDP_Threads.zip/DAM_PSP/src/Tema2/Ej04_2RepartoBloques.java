package Tema2;

import java.util.Scanner;

public class Ej04_2RepartoBloques {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la cantidad total de trabajo (N): ");
        int N = sc.nextInt();

        System.out.print("Introduce el número de hilos (M): ");
        int M = sc.nextInt();

        //Calculamos el tamaño de bloque base
        int blockSize = (N + M - 1) / M; //Tenemos en cuenta el máximo resto posible +M-1

        //Definimos el array de hilos solicitados:
        Thread[] hilos = new Thread[M];

        System.out.println("COMIENZA LA IMPLEMENTACIÓN POR BLOQUES:");

        //Calculamos el indice inicial y final para cada hilo según reparto por bloques:
        for(int i = 0; i < M; i++) {
            int numIni = i * blockSize;//indice inicial para este hilo
            int numFin = Math.min(numIni + blockSize, N);//indice final para este hilo

            //Instanciamos el hilo:
            hilos[i] = new Thread(new HiloBloques(numIni, numFin, i));
            hilos[i].start();//Arrancamos el hilo.
            //Cada hilo procesará los indices del trabajo indicados, según un reparto por bloques.
        }

        //Esperamos a que todos los hilos terminen:
        for (Thread hilo : hilos) {
            try{
                hilo.join();
            } catch(InterruptedException e){
                e.printStackTrace();
            }
        }

        System.out.println("Todos los hilos han finalizado.");
    }
}


class HiloBloques implements Runnable{
    private int numIni;
    private int numFin;
    private int id;

    HiloBloques(int numIni, int numFin, int id) {
        this.numIni = numIni;
        this.numFin = numFin;
        this.id = id;
    }

    @Override
    public void run() {
        //El hilo procesa el bloque de trabajo recibido:
        for(int i = numIni; i < numFin; i ++) {
            System.out.println("Soy el hilo " + id + ", digo el número " +
                    i + " y el cuadrado es " + CalculaCuadrado(i));
        }
    }

    public int CalculaCuadrado(int n){
        return n*n;
    }
}
