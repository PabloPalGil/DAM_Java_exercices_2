package Tema2;

public class Ej01Threads {
    public static void main(String[] args) {
        //Creamos un array de 8 instancias de MiTarea_Thread, que extiende Thread
        MiTarea_Thread[] hilos = new MiTarea_Thread[8];

        //En este punto el array de hilos está vacío, tenemos que asignar a cada hilo su tarea
        for(int i = 0; i < hilos.length; i++) {
            hilos[i] = new MiTarea_Thread();

            //Iniciamos cada hilo
            hilos[i].start();
        }

        //Iniciamos la tarea del hilo principal
        for (int i = 1; i <= 5; i++) {
            System.out.println("Hilo principal: Contador " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        //Esperamos a que todos los hilos acaben
        try {
            for (int i = 0; i < hilos.length; i++) {
                hilos[i].join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("El programa ha finalizado.");
    }
}

class MiTarea_Thread extends Thread {
    public void run() {
        //Código que ejecutará el hilo
        for (int i = 1; i <= 5; i++) {
            System.out.println("Hilo " + threadId() + ": Contador " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}