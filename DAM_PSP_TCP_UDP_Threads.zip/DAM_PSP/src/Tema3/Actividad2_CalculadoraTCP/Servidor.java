package Tema3.Actividad2_CalculadoraTCP;

import java.io.*;
import java.net.*;

public class Servidor {
    //Al arrancar la aplicación, creamos el servidor y esperamos la llegada de clientes
    public static void main(String[] args) {
        try {
            // Crear un servidor que escucha en el puerto 12345
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Servidor esperando conexiones...");


            //Bucle infinito que espera nuevos clientes
            while (true) {
                //Inicializamos nuestro Socket para esperar al siguiente cliente:
                Socket clientSocket;

                clientSocket = serverSocket.accept(); //Esperamos y aceptamos la nueva conexión
                System.out.println("Nuevo cliente conectado.");

                // Crear un hilo para manejar la conexion del cliente
                Thread clientThread = new Thread(new ClienteHandler(clientSocket));
                clientThread.start();
                System.out.println("Servidor: hilo cliente conectado.");
            }

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Servidor desconectado.");
            System.exit(0);//Salimos del programa
        } catch (Exception e){
            System.out.println("Servidor desconectado.");
            System.exit(0);//Salimos del programa
        }
    }
}

//Clase que maneja la operativa de un nuevo cliente a partir del Socket en un hilo independiente para el cliente
class ClienteHandler implements Runnable {
    private Socket clientSocket; //variable del Socket del cliente

    //Constructor, se pasa el Socket que conecta con el cliente como parámetro
    public ClienteHandler(Socket socket) {
        this.clientSocket = socket; //Asignamos el socket
    }

    //Lógica del servidor que dará respuesta a las peticiones del cliente:
    public void run() {
        //Abrimos los flujos de entrada / salida con el cliente
        try {
            //Flujo de entrada de bytes:
//            InputStream inputStream = clientSocket.getInputStream(); //Flujo de entrada de bytes
//            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream)); //Búfer de lectura del flujo de entrada

            //Flujo de salida de bytes:
//            OutputStream outputStream = clientSocket.getOutputStream();
            //Escritor de salida que convierte caracteres en bytes, con auto-flush
            // para limpiar el flujo de salida tras imprimir con printf(), println() o format():
//            PrintWriter out = new PrintWriter(outputStream, true);

            //Flujo de entrada de caracteres
            DataInputStream in = new DataInputStream(clientSocket.getInputStream());

            //Flujo de salida de caracteres:
            DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

            //Lógica de la calculadora:
            int op = -1; //Inicializamos en -1
            int n1;
            int n2;
            boolean salir = false;

            //La calculadora se ejecutará hasta que el usuario salga con la opción 0
            //Se recibe un String con el formato “op#n1#n2” donde op será el valor de la operación a
            //realizar (1 a 4), n1 el primer operador y n2 el segundo.
            while (!salir) {
                try{
                    //leemos el mensaje que llega del cliente:
                    String mensaje = in.readUTF(); //Inicializamos la variable que recogerá los mensajes del cliente
//                    System.out.println("Servidor: mensaje leído: " + mensaje);
                    String[] datos = mensaje.split("#"); //Dividimos según el formato para obtener los datos
                    op = Integer.parseInt(datos[0]);//La operación es el primer miembro
                    n1 = Integer.parseInt(datos[1]);//El primer valor es el segundo miembro
                    n2 = Integer.parseInt(datos[2]);//El segundo valor es el tercer miembro

                    //Ahora realizamos la operación solicitada:
                    switch (op) {
                        case 1 -> out.writeUTF(String.valueOf(n1 + n2));
                        case 2 -> out.writeUTF(String.valueOf(n1 - n2));
                        case 3 -> out.writeUTF(String.valueOf(n1 * n2));
                        case 4 -> {
                            if (n2 == 0)
                                out.writeUTF("Error: division por 0");
                            else
                                out.writeUTF(String.valueOf((double)n1 / (double)n2));
                        }
                    }
                } catch(IOException e){
                    e.printStackTrace();
                    System.out.println("Servidor: error al leer del cliente.");
                    salir = true;
                }
            }
        } catch (SocketException se) {//Por si el cliente se desconecta de forma inesperada
            se.printStackTrace();
            System.out.println("Servidor: error al leer del cliente.");
            System.exit(0);//Salimos del programa
        } catch (IOException e) { //Por si hay algún error con los flujos de E/S
            e.printStackTrace();
            System.out.println("Servidor: error de E/S.");
            System.exit(0);//Salimos del programa
        } finally {
            try{
                if(!clientSocket.isClosed())
                    clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}