package Tema3.Actividad2_CalculadoraTCP;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    Socket socket = null;
    DataInputStream fentrada;
    DataOutputStream fsalida;
    boolean repetir = true;//Controlamos la salida y desconexión del servidor

    Cliente(Socket socket){
        this.socket = socket;

        //Abrimos los flujos de E/S:
        try {
            //Flujo de entrada de caracteres:
            fentrada = new DataInputStream(socket.getInputStream());
            //Flujo de salida de caracteres:
            fsalida = new DataOutputStream(socket.getOutputStream());

        } catch (IOException e) {
            System.out.println("ERROR DE E/S");
            e.printStackTrace();
            System.exit(0);//Salimos del programa
        }

        //Lógica de la calculadora:
        try{
            while(repetir){
                String mensaje;
                String respuesta = "";
                try{
                    mensaje = pedirOperacion(); //Aquí almacenaremos el mensaje a enviar al servidor
                    fsalida.writeUTF(mensaje);//Enviamos el mensaje al servidor

                    respuesta = fentrada.readUTF();//Leemos la respuesta del servidor

                    System.out.println(respuesta);//Imprimimos el resultado por pantalla

                    //Preguntamos al cliente si quiere hacer otra operación:
                    if(solicitarSalida())
                        repetir = false;
                } catch(IOException e){
                    e.printStackTrace();
                }
            }
            //Cerramos el socket cuando terminamos de usarlo
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




    public static void main(String[] args) {
        Socket socket = null;
        //Intentamos la conexión
        try {
            // Establecer conexion con el servidor en el puerto 12345
            socket = new Socket("localhost", 12345);
            System.out.println("Conexión establecida con el servidor.");
        } catch (IOException e) {
            System.out.println("Imposible conectar con el servidor.");
            e.printStackTrace();
            System.exit(0);//Salimos del programa
        }

        //Llamamos a la clase Cliente de Calculadora
        new Cliente(socket);
    }

    //Método que solicita y valida al usuario los datos necesarios para realizar la operación:
    public String pedirOperacion() {
        Scanner sc = new Scanner(System.in);
        String mensaje = "";
        int input; //Inicializamos en -1
        boolean valido = false;//Controlamos que las entradas son correctas

        while(!valido){
            //Pedimos la operación:
            System.out.println("Introduce tipo de operación: 1-Suma, 2-Resta, 3-Multiplicación, 4-División:");

            //Comprobamos que se haya introducido un número entero
            input = validaEntero();
            //Comprobamos que sea una de las opciones disponibles:
            if(input < 1 || input > 4) {
                System.out.println("Error: Debes introducir una de las opciones disponibles.");
                continue;//Empezamos de nuevo
            }
            //Si la entrada es correcta, lo guardamos en el mensaje
            mensaje = input + "#";

            //Pedimos y comprobamos el primer valor:
            System.out.println("Introduce el primer valor:");
            input = validaEntero();
            //Actualizamos el mensaje:
            mensaje += input + "#";

            //Pedimos y comprobamos el segundo valor:
            System.out.println("Introduce el segundo valor:");
            input = validaEntero();
            //Finalizamos el mensaje:
            mensaje += input;
            valido = true;
        }
        //Devolvemos el mensaje con el formato requerido
        return mensaje;
    }


    //Método que valida si se ha introducido un número entero
    public int validaEntero(){
        Scanner sc = new Scanner(System.in);

        //Comprobamos que se haya introducido un número entero
        while(!sc.hasNextInt()){
            System.out.println("Error: Debes introducir un número entero.");
            sc.next(); // Descarta el valor no entero ingresado
        }
        return sc.nextInt();//Devolvemos el entero
    }


    //Método que solicita al usuario si quiere realizar otra operación
    public boolean solicitarSalida() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Si quieres hacer otra operación inserta cualquier" +
                " valor numérico que no sea 0, si quieres salir inserta 0.");

        if(sc.nextInt() == 0){
            return true;
        } else{
            return false;
        }
    }
}