package Tema3.EjemploTCP;

import java.io.*;
import java.net.*;

public class Servidor {
    public static void main(String[] args) {
        try {
            // Crear un servidor que escucha en el puerto 12345
            ServerSocket serverSocket = new ServerSocket(12345);
            System.out.println("Servidor esperando conexiones...");

            // Logica para manejar multiples clientes
            while (true) {
                // Aceptar una nueva conexion de cliente
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nuevo cliente conectado.");

                // Crear un hilo para manejar la conexion del cliente
                Thread clientThread = new Thread(new ClienteHandler(clientSocket));
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class ClienteHandler implements Runnable {
    private Socket clientSocket;

    public ClienteHandler(Socket socket) {
        this.clientSocket = socket;
    }

    public void run() {
        try {
            // Logica para enviar y recibir datos con el cliente
            InputStream inputStream = clientSocket.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            String mensaje = in.readLine();
            System.out.println(mensaje);


            OutputStream outputStream = clientSocket.getOutputStream();
            PrintWriter out = new PrintWriter(outputStream, true);
            out.println("Hola, cliente!");
            // Cerrar el socket cuando termines de usarlo
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}