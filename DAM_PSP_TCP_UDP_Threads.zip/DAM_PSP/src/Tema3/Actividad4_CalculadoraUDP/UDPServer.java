package Tema3.Actividad4_CalculadoraUDP;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPServer {
    public static void main(String[] args) {
        //La instancia del socket la dejamos fuera del try para poder cerrarlo en el catch/finally
        DatagramSocket socket = null;
        try {
            //Creamos el DatagramSocket del servidor
            socket = new DatagramSocket(9876);

            //Creamos el tamaño del búfer de lo que vamos a recibir
            byte[] receiveData = new byte[1024];

            while (true) {
                //Creamos el DatagramPacket (lo que envuelve al contenido a recibir a través del DatagramSocket)
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);//Espero a recibir de un cliente

                //Recepcionamos el mensaje del cliente (de bytes a un String) en su totalidad (de 0 a su longitud):
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());

                //Obtenemos también la dirección y el puerto del cliente:
                InetAddress clientAddress = receivePacket.getAddress(); //Dirección IP del cliente
                int clientPort = receivePacket.getPort(); //Puerto del cliente
                String serverMessage = ""; //Aquí almacenaremos el contenido del mensaje de vuelta, si es necesario

                //Desciframos el mensaje del cliente:
                String[] datos = message.split(":");
                String op = datos[0];
                int n1 = Integer.parseInt(datos[1]);
                int n2 = Integer.parseInt(datos[2]);


                //Realizamos la operación:
                if (op.equals("SUMA")) {
                    serverMessage = String.valueOf(n1 + n2);
                } else if (op.equals("RESTA")) {
                    serverMessage = String.valueOf(n1 - n2);
                } else {
                    System.out.println("Petición incorrecta.");
                }

                //Convertimos nuestro mensaje String a bytes (se envían bytes)
                byte[] sendData = serverMessage.getBytes();

                //Creamos el DatagramPacket para devolver el mensaje al cliente:
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                socket.send(sendPacket);//Enviamos
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}