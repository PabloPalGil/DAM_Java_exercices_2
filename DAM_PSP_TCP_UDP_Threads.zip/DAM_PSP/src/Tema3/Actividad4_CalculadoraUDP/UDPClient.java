package Tema3.Actividad4_CalculadoraUDP;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {
    public static void main(String[] args) {
        //La instancia del socket la dejamos fuera del try para poder cerrarlo en el catch/finally
        DatagramSocket datagramSocket = null;//DatagramaSocket del protocolo UDP
        try {
            //Inicializamos las clases para la comunicación UDP
            datagramSocket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName("localhost"); //Direccion IP del servidor
            int serverPort = 9876;//Puerto del servidor

            //Definimos la lógica del cliente de la aplicación:
            //Bucle infinito del que sólo saldremos cuando el usuario elija salir
            while (true) {
                String message = pedirOperacion();

                //System.out.println("Cliente: mensaje generado: " + message);

                //Comprobamos si el usuario quiere salir
                if (message.equals("EXIT")) {
                    break;
                }

                //Convertimos nuestro mensaje String a bytes (porque se envían bytes)
                byte[] sendData = message.getBytes();//contenido en bytes del mensaje a enviar al servidor
                byte[] receiveData = new byte[1024];//preparamos la variable para leer la respuesta del servidor

                //Envolvemos el mensaje en su totalidad (ya en bytes) en la clase DatagramPacket para poder
                // enviarla a través del DatagramSocket a la direción IP y puerto del servidor:
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
                datagramSocket.send(sendPacket);//Enviamos


                //Crear el paquete para recibir la respuesta del servidor
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                //Esperamos la respuesta del servidor
                datagramSocket.receive(receivePacket);

                // Leer y mostrar la respuesta del servidor
                String serverResponse = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Respuesta: " + serverResponse);
            }
            System.out.println("Saliendo del programa...");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Si el DatagramSocket está abierto, lo cerramos:
            try{
                if (!datagramSocket.isClosed()) {
                    datagramSocket.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            System.exit(0);//Detenemos la ejecución del programa
        }
    }


    //Método que solicita y valida al usuario los datos necesarios para realizar la operación:
    public static String pedirOperacion() {
        Scanner sc = new Scanner(System.in);
        String mensaje = "";
        int input; //Inicializamos en -1
        boolean valido = false;//Controlamos que las entradas son correctas

        while(!valido){
            //Pedimos la operación:
            System.out.println("Escribe la operación a realizar (SUMA o RESTA, o EXIT para salir):");

            mensaje = sc.nextLine();

            //Comprobamos que se haya introducido una operación válida
            while(!mensaje.trim().equalsIgnoreCase("SUMA")
                    && !mensaje.trim().equalsIgnoreCase("RESTA")
                    && !mensaje.trim().equalsIgnoreCase("EXIT")){
                System.out.println("Error: Debes introducir una operación válida.");
                mensaje = sc.next();
            }
            //Comprobamos si ha solicitado salir:
            if(mensaje.equalsIgnoreCase("EXIT")){
                break;
            }

            //Si la entrada es correcta, lo guardamos en el mensaje y añadimos el metacaracter ":"
            mensaje += ":";

            //Pedimos y comprobamos el primer valor:
            System.out.println("Introduce el primer valor:");
            input = validaEntero();
            //Actualizamos el mensaje:
            mensaje += input + ":";

            //Pedimos y comprobamos el segundo valor:
            System.out.println("Introduce el segundo valor:");
            input = validaEntero();
            //Finalizamos el mensaje:
            mensaje += input;
            valido = true;
        }
        //Devolvemos el mensaje con el formato requerido
        return mensaje.toUpperCase();
    }


    //Método que valida si se ha introducido un número entero
    public static int validaEntero(){
        Scanner sc = new Scanner(System.in);

        //Comprobamos que se haya introducido un número entero
        while(!sc.hasNextInt()){
            System.out.println("Error: Debes introducir un número entero.");
            sc.next(); // Descarta el valor no entero ingresado
        }
        return sc.nextInt();//Devolvemos el entero
    }
}