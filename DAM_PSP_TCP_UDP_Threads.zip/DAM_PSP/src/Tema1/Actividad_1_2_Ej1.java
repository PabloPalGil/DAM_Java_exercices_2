package Tema1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Actividad_1_2_Ej1 {
    public static void main(String[] args){

        //Creamos una instancia de Runtime
        Runtime runtime = Runtime.getRuntime();

        //Escribimos el manejo de Runtime en un bloque try-catch
        //porque trabajamos con programas externos a Java:
        try {
            //Como estamos en Windows, ejecutamos el comando "tasklist"
            Process proceso = runtime.exec("tasklist");

            //Como vamos a leer texto, abrimos un buffer reader para leer la salida del comando
            BufferedReader reader = new BufferedReader(new InputStreamReader(proceso.getInputStream()));

            String linea;//Creamos una variable String para almacenar cada línea que leamos

            //Mientras haya una línea más que leer:
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);//mostramos la línea leída por consola
            }

            //En este punto ya hemos leído el resultado y sólo queda esperar a que el proceso termine:
            int resultado = proceso.waitFor();

            //Si waitFor devuelve 0, la ejecución terminó sin errores
            if(resultado == 0){
                System.out.println("El comandó se ejecutó con exito. Código de salida: " + resultado);
            } else {
                System.out.println("Error en la ejecución del comando. Código de salida: " + resultado);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}