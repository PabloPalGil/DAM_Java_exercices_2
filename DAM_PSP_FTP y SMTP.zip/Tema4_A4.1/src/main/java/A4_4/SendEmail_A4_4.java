package A4_4;

//import javax.mail.Message;
//import javax.mail.Multipart;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;


public class SendEmail_A4_4 {

    public void mandarCorreo() {
        // El correo gmail de envío
        String correoEnvia = "pablo.espiral@gmail.com";
        String claveCorreo = "lief pavr bmat fmou";

        //Añadimos el email de registro del nuevo usuario:
        String userEmail = "pabpalgil@alu.edu.gva.es"; //mi email del instituto para comprobar que funciona

        // La configuración para enviar correo
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.ssl.protocols", "TLSv1.2");
        properties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.user", correoEnvia);
        properties.put("mail.password", claveCorreo);

        // Obtener la sesion
        Session session = Session.getInstance(properties, null);

        try {
            // Crear el cuerpo del mensaje
            MimeMessage mimeMessage = new MimeMessage(session);

            // Agregar quien envía el correo
            mimeMessage.setFrom(new InternetAddress(correoEnvia));

            // Los destinatarios
            InternetAddress[] internetAddresses = {
                    new InternetAddress("pabpalgil@alu.edu.gva.es")};

            // Agregar los destinatarios al mensaje
            mimeMessage.setRecipients(Message.RecipientType.TO,
                    internetAddresses);

            // Agregar el asunto al correo
            mimeMessage.setSubject("¡Bienvenido a mi sitio web!");

            // Creo la parte 1 del mensaje: texto en formato html
            MimeBodyPart htmlPart = new MimeBodyPart();
            String htmlContent = "<!DOCTYPE html>" +
                    "<html lang=\"es\">" +
                "<body>" +
                "<h1 style=\"color: #0000ff;\">¡Bienvenido/a al sitio web de Pablo Palanques!" +
                    "</h1><p>Hola:</p>" +
                    "<p>Te doy la bienvenida a mi espectacular sitio web. Ya puedes empezar a explorar.</p>" +
                    "<p><a href=\"https://portal.edu.gva.es/ieselcaminas/es/centro/\" style=\"color: #007bff;\">Haz clic aquí para empezar</a></p>" +
                    "</body>" +
                    "</html>";
            htmlPart.setContent(htmlContent,  "text/html; charset=utf-8");

            // Creo la parte 2 del mensaje: imagen adjunta
            MimeBodyPart imagePart = new MimeBodyPart();
            //La ruta de la imagen:
            String imgPath = "C:\\smtp\\logoCaminas.png";
            //Indicamos la fuente de datos (DataSource) a partir del archivo que queremos adjuntar:
            DataSource source = new FileDataSource(imgPath);
            //Establecemos el DataHandler para que JavaMail comprenda cómo adjuntar la imagen:
            imagePart.setDataHandler(new DataHandler(source));
            imagePart.setFileName("iesCaminas.png");//Definimos el nombre de la imagen desde el cliente del correo

            // Crear el multipart para agregar la parte del mensaje anterior
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(htmlPart); //Añadimos la parte dle texto html
            multipart.addBodyPart(imagePart); //Añadimos la parte de la imagen adjunta

            // Agregar el multipart al cuerpo del mensaje
            mimeMessage.setContent(multipart);


            // Enviar el mensaje
            Transport transport = session.getTransport("smtp");
            transport.connect(correoEnvia, claveCorreo);
            transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
            transport.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("Acabo de enviar un correo desde " + correoEnvia);
    }

    public static void main(String[] args) {
        SendEmail_A4_4 correoTexto = new SendEmail_A4_4();
        correoTexto.mandarCorreo();
    }
}